﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LB6
{
    public partial class Form3 : Form
    {
        public ProgressBar but1;
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if ((Convert.ToInt32(textBox1.Text) < 100) && (Convert.ToInt32(textBox1.Text) >= 0))
                but1.Value = Convert.ToInt32(textBox1.Text);
        }
    }
}
