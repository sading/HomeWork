﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LB2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    Left -= 10;
                    break;
                case Keys.Right:
                    Left += 10;
                    break;
                case Keys.Oemplus:
                    Width += 10;
                    Height += 10;
                    break;
                case Keys.OemMinus:
                    Width -= 10;
                    Height -= 10;
                    break;
            }

            if ((e.KeyCode == Keys.X) && e.Alt)
            {
                Close();
            }
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Поменять цвет?", "Форма запроса", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                BackColor = Color.Green;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Поменять цвет?", "Форма запроса", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                BackColor = Color.Gray;
        }

        private void ListOfCursors_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (ListOfCursors.SelectedIndex)
            {
                case 0:
                    Cursor = Cursors.Default;
                    break;
                case 1:
                    Cursor = Cursors.Hand;
                    break;
                case 2:
                    Cursor = Cursors.AppStarting;
                    break;
                case 3:
                    Cursor = Cursors.WaitCursor;
                    break;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = checkBox1.Checked;
        }

        private void checkBox2_Click(object sender, EventArgs e)
        {
            button1.Visible = !checkBox2.Checked;
        }

        private void checkBox3_Click(object sender, EventArgs e)
        {
            ListOfCursors.Enabled = !checkBox3.Checked;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (ListOfCursors.SelectedIndex)
            {
                case 0:
                    BackColor = Color.White;
                    break;
                case 1:
                    BackColor = Color.Red;
                    break;
                case 2:
                    BackColor = Color.Green;
                    break;
                case 3:
                    BackColor = Color.Blue;
                    break;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                FormBorderStyle = FormBorderStyle.Sizable;
            }
            else
            {
                FormBorderStyle = FormBorderStyle.None;
            }
            
         
            
        }
    }
}
